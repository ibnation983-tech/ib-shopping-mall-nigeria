IB SHOPPING MALL — PREMIUM STOREFRONT

Open index.html in a browser to preview the website.
Includes five departments, a 25-item catalogue, category filters, search,
naira price displays and WhatsApp enquiry links.

The catalogue is prepared as the shopping list for the store's opening stock.
The photographs are editorial reference images and may not depict the exact
supplier item. The displayed prices are planning prices and should be checked
against supplier quotations before final customer orders are accepted.
Replace reference photos with exact supplier/product photos as stock is selected.
Confirm product brands, specifications, sizes, expiry dates, authenticity,
final selling prices and delivery charges before accepting payment.

WhatsApp and email contact links are configured with the business contact details.
Images and Google Fonts load from the internet, so an internet connection is needed.
This package is ready for static hosting; it is not published online automatically.
